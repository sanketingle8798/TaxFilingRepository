package com.example.TaxFilingAppicationSprint2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxFilingAppicationSprint2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
